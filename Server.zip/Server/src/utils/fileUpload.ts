import * as AWS from "aws-sdk";
import * as uuidv4 from "uuid/v4";
import * as fileSys from "fs";
import * as utilIns from "util";
import path = require("path");
//import {SunProError} from "../../../shared/types/error";
//import {UPLOAD_FAILED, ERR_014} from "../../../shared/types/error-codes-messages";

const unlinkIns = utilIns.promisify(fileSys.unlink);

AWS.config.update({
  region: "us-east-2",
  secretAccessKey: 'RVBaYwCpoI8i1Ry3rX9QNpyhxZbNh075PxBIqVff',
  accessKeyId: 'AKIATLVYRTI2XMXKANHD'
});

const albumBucketName = "ggiri.storage";//production

const s3 = new AWS.S3({
  apiVersion: "2006-03-01",
  params: { Bucket: albumBucketName }
});

let options = { partSize: 10 * 1024 * 1024, queueSize: 1 };

export default async function upload(files,user_id, fileType = "", htmlPath = "", name = "", pdfPath = "") {
  //console.log("Inside Upload");
  var url = files.category.toUpperCase() == "DRIVER" ? "DRIVER" : (files.category.toUpperCase() == "OPERATOR" ? "OPERATOR" : (files.category.toUpperCase() == "OWNER" ? "OWNER" : "OPERATOR_DRIVER"))
  var save_path = "UserProfiles"+'/'+url+'/'+user_id+'_'+files.name
  var list_files;

  if(files.category.toUpperCase() == "OWNER"){
    list_files = [files.profile_pic, files.front_view, files.back_view, files.electricity_bill]
  }
  else{
    list_files = [files.profile_pic, files.front_view, files.back_view]
  }

  if(user_id==""){
     save_path = "Vehicles"
     list_files = files.images
  }
   
  let fileResp = []
  var user = files.name

  var wait_data = (list_files.map(async (pic: any) => {
    let file_name = (pic) ? pic.hapi.filename : '';
    let file_type = (file_name) ? file_name.split('.')[1] : ''
    
    const fileName = name ? `${save_path}/${name}.${file_type}` : `${save_path}/${uuidv4()}.${file_type}`;
    console.log(file_name,file_type,'*',fileName)
    let params = {
      Bucket: albumBucketName,
      Key: fileName,
      Body: pic
    };
    await s3
      .upload(params, options)
      .promise()
      .then(res => {
        fileResp.push(res.Location)
        // if (fileType === "pdf" || fileType === "txt") {
        //   //console.log(htmlPath);
        //   unlinkIns(htmlPath).catch(err => {
        //     //console.log("File not found, moving ahead.");
        //   });
        //   unlinkIns(pdfPath).catch(err => {
        //     //console.log("File not found, moving ahead.");
        //   });
        // }
      })
      .catch(err => {
        console.error("#####",err)
      });
   
}))
  const users = await Promise.all(wait_data);
  //console.log(fileResp)
  return fileResp;
}
