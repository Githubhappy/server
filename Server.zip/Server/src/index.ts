// index.ts 
/**
 * Implementation of Server start
 * @packageDocumentation
 */
// Importing all external modules  
import { config } from 'dotenv';
import { resolve } from 'path';

// Load the .env file before loading custom modules otherwise models will fail
config( { path : resolve( __dirname +  '/../.env' ) } );


// Importing custom modules
import setupServer  from './server';
import authDataService from './models/auth.model';





// Setup the server by injecting the dataservice
const server = setupServer( {...authDataService } );
server();
