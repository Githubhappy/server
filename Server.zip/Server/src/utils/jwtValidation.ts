
import { AuthDBConnection } from '../config/dbconnection'
import * as T from '../types/types';
import * as DB from '../utils/dbTables';
var jwt_Decode = require('jwt-decode');
import * as jwt from 'jsonwebtoken';

async function jwtDecodeDBOperation(input: String): Promise<T.DBResponseType> {

    const jwtDecodeAPIresponse: T.DBResponseType = {
        status: true,
        token: false
    };
    var bool = false;
    try {
        var exp = new Date();
        exp.setDate(exp.getDate() + 1);
        let jwt_curr_time = { 'exp': Math.floor(Date.now() / 1000) };
        var jwt_token = jwt_Decode(input);
        await DB.Login.forge()
            .query((qb) => {
                qb.column('id','phone','category')
                    .where('user_id', '=', jwt_token.user_id);
            })
            .fetch()
            .then((response: any) => {
                const res = response.toJSON();
                jwtDecodeAPIresponse.id = res.id;
                let data = {"phone":res.phone, "user_id": jwt_token.user_id,'category':res.category}
                if (jwt_token.exp >= jwt_curr_time.exp) {
                    jwtDecodeAPIresponse.data = data
                    jwtDecodeAPIresponse.status = true;
                    jwtDecodeAPIresponse.message = "jwtToken_success";
                }
                else {
                    jwtDecodeAPIresponse.status = false;
                    jwtDecodeAPIresponse.message = "jwtToken_issue"
                    jwtDecodeAPIresponse.data = data
                    jwtDecodeAPIresponse.token = true
                }

            })
            .catch((error: any) => {
                console.log("error", error);
                jwtDecodeAPIresponse.status = false;
                jwtDecodeAPIresponse.message = "jwtToken_fail";
                jwtDecodeAPIresponse.data = {};
            });

        // if (jwtDecodeAPIresponse.status) {
        //     await DB.login_logout_iterations
        //         .forge()
        //         .query((qb) => {
        //             qb.where({ 'login_id': jwt_token.id, 'active': true, 'uuid': jwt_token.uuid });
        //         })
        //         .fetch()
        //         .then((response: any) => {
        //             console.log("active user");
        //         })
        //         .catch((err) => {
        //             bool = true
        //             console.log("error", err);
        //             jwtDecodeAPIresponse.status = false;
        //             jwtDecodeAPIresponse.message = messages.jwt_logout
        //             jwtDecodeAPIresponse.data = {}
        //         })
        // }
    }
    catch (error) {
        console.log("error", error);
        jwtDecodeAPIresponse.status = false;
        jwtDecodeAPIresponse.message = "jwtToken_fail";
        jwtDecodeAPIresponse.data = {};
    }
    return jwtDecodeAPIresponse;
}
async function jwtTokenEncoder(input: String): Promise<T.DBResponseType> {

    const jwtEncoderAPIresponse: T.DBResponseType = {
        status: true
    };
    //console.log("######  jwtid",input)
    let curr_jwtPayload = {'user_id': input, 'iss': 'ggiri', 'exp': Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 90) };
    let curr_token = jwt.sign(curr_jwtPayload, 'password!!');

    let refresh_jwtPayload = {'user_id': input, 'iss': 'ggiri', 'exp': Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 92)};
    let refresh_token = jwt.sign(refresh_jwtPayload, 'password!!');

    let token = { 'token': curr_token, 'refresh': refresh_token };
    let active = 1;

    // var exp: any = Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 90);
    // exp = moment(new Date(exp * 1000).toLocaleString()).format('YYYY-MM-DD HH:mm:ss');
    // //console.log(exp)
    // var curr = moment(new Date(Date.now())).format('YYYY-MM-DD HH:mm:ss');
    // //console.log("**",curr)
    // await login_logout_insert(input, uuid, active, curr, exp)
    //     .then((res) => {
    //         console.log(res);
    //     })
    //     .catch((err) => {
    //         console.log(err);
    //     })

    jwtEncoderAPIresponse.data = token;
    jwtEncoderAPIresponse.status = true;
    jwtEncoderAPIresponse.message = "jwt encoder";
    return jwtEncoderAPIresponse;
}

export default {
    jwtDecoder: jwtDecodeDBOperation,
    jwtEncoder: jwtTokenEncoder,
}
