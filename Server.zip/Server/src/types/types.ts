// types.ts 
/**
 * Definition of custom API types used in the implementation 
 * @packageDocumentation
 */

'use strict'
// Import user defined data types
import * as T from './data-types';


/**
 * Definition of AuthAPI Type
 */
export type AuthAPIType  =  {
    login: ( input : any ) => Promise<T.DBResponseType>;
    loginmobile: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
    verifyOTPRoute: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
    registerOperatorDriver:( input : any, auth:any ) => Promise<T.DBResponseType>;
    registerOwner:( input : any, auth:any ) => Promise<T.DBResponseType>;
    vehilesUpload:( input : any ) => Promise<T.DBResponseType>;
    vehileDetails:( auth:any ) => Promise<T.DBResponseType>;
    timeSlotWorkType:( input : any, auth:any ) => Promise<T.DBResponseType>;
    getProfile:( auth : any ) => Promise<T.DBResponseType>;
    operatorDriverVehiles:( input : any, auth:any ) => Promise<T.DBResponseType>;
    ownerVehiles:( input : any, auth:any ) => Promise<T.DBResponseType>; 
    kycStatusChange:( input : any, auth:any ) => Promise<T.DBResponseType>; 
    kycStatusDetails:( input : any, auth:any ) => Promise<T.DBResponseType>; 
    userPaymentData:( input : any, auth:any ) => Promise<T.DBResponseType>; 
    userPaymentDataSave:( input : any, auth:any ) => Promise<T.DBResponseType>; 
};


export  *  from './data-types'