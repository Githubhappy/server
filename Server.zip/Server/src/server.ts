import { Server, Request, ServerOptions, ResponseToolkit } from "@hapi/hapi";
//import { initPlugins } from "./plugins";
import { initPlugins } from "./plugins";
import { initRoutes }  from './routes';

import  * as R  from 'ramda';

const promisify = ( fn: any ) => ( x: any ) => Promise.resolve( fn( x ));

export const createServer = ( config: ServerOptions ): Server =>  { 
    console.log('[server.ts:¡:createServer] called'); 
    const server = new Server( config );
    server.validator( require( '@hapi/joi' ) );

    return server;
};

// Get configuration for hapi server 
export const getServerConfig = (): ServerOptions => ( {
    host: process.env.SERVER_HOST || '0.0.0.0',
    port: 3010,
    routes: {
        cors: {
            origin: ["*"] 
        }
    }
} );

// start HAPI server
export const start =  ( server: Server ) => {
    server.start();
    return server;
};

// We dont need to do this for REST APIs 
const onPreResponse = ( request, reply ) => {
    const { response } = request;
    return reply.continue;
};

const registerIntercepts = ( server ) => {
    server.ext('onPreResponse', onPreResponse);
    return server;
};

// Install unhandled rejection error handler
const installExceptionHandler = () => process.on( 'unhandledRejection', ( err ) => {
        console.log( err );
        process.exit( 1 );
});

const setupServer = ( dataservice : any ):any => R.compose(
    (server: Server ) => { 
        console.log( 'Server started',  server.info.uri ) 
    },
    R.compose( start, initRoutes( dataservice ) ),
    createServer,
    getServerConfig,
    installExceptionHandler
);

export default setupServer;

