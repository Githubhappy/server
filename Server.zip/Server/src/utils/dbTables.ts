import { AuthDBConnection } from "../config/dbconnection";

export const Login = AuthDBConnection.Model.extend({
    tableName: "login",
    hasTimestamps: ["created", "modified"],
});
export const driver_operator = AuthDBConnection.Model.extend({
    tableName: "driver_operator",
    hasTimestamps: ["created", "modified"],
});

export const owner = AuthDBConnection.Model.extend({
    tableName: "owner",
    hasTimestamps: ["created", "modified"],
});

export const vehicleList = AuthDBConnection.Model.extend({
    tableName: "vehicle_list",
    hasTimestamps: ["created", "modified"],
});

export const timeslotWorktype = AuthDBConnection.Model.extend({
    tableName: "timeslot_worktype",
    hasTimestamps: ["created", "modified"],
});

export const driver_operator_vehicles = AuthDBConnection.Model.extend({
    tableName: "driver_operator_vehicles",
    hasTimestamps: ["created", "modified"],
});

export const owner_vehicles = AuthDBConnection.Model.extend({
    tableName: "owner_vehicles",
    hasTimestamps: ["created", "modified"],
});

export const kyc_status = AuthDBConnection.Model.extend({
    tableName: "kyc_status",
    hasTimestamps: ["created", "modified"],
});

export const user_payment_data = AuthDBConnection.Model.extend({
    tableName: "user_payment_data",
    hasTimestamps: ["created", "modified"],
});