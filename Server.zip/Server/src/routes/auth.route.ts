import * as Joi from '@hapi/joi';
import URL from '../urls';
import * as T from '../types/types';

import { RouteOptionsPayload } from '@hapi/hapi';
import path = require('path');
import upload from '../utils/fileUpload';

const WelcomeRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        const loginAPIresponse :  T.DBResponseType = {
            status: true,
            message: "Welcome to Gigiri"
        };
        console.log( 'auth.route.js::helloRouteHandler');
        return loginAPIresponse
        //return dataservice.login( request.payload ); 
    }    
}

const Welcome  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'GET',
    options: {
        handler: WelcomeRouteHandler( dataservice ),
        validate: {
        }
    },
    path: URL.WELCOME,
} );


const loginmobileRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::loginRouteHandler  request', request.payload );
        return dataservice.loginmobile( request.payload ); 
    }    
}

const loginmobileRoute  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: loginmobileRouteHandler( dataservice ),
        validate: {
            payload: {
                phone: Joi.string().pattern(new RegExp('^[+]?(\d{1,2})?[0-9]{3,15}$')).error(new Error("Enter a valid mobile number.")).required(),
                category : Joi.string().error(new Error("Please enter the category.")).required(),       
            },
            failAction: (request, h, err) => {
                throw err;
                return false;
            },
        }
    },
    path: URL.LOGIN_MOBILE,
} );


const verifyOTPRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::loginRouteHandler  request', request.payload );
        return dataservice.verifyOTPRoute( request.payload ); 
    }    
}

const verifyOTPRoute  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: verifyOTPRouteHandler( dataservice ),
        validate: {
            payload: {
                phone: Joi.number().required(),
                otp:Joi.number().required(),
            }
        }
    },
    path: URL.VERIFY_OTP,
} );


const updateRouteOptions: RouteOptionsPayload = {
    allow: "multipart/form-data",
    maxBytes: 20 * 1000 * 1000 ,
    parse: true,
    timeout: false,
    multipart: {
    output: 'stream'
    }
    //output: "stream",
    };


const registerOperatorDriverHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.registerOperatorDriver(request.payload,request.headers.authorization) 
    }    
}

const registerOperatorDriver  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: registerOperatorDriverHandler( dataservice ),
        validate: {
                payload: Joi.object({
                    //id:Joi.number().error(new Error("Please enter id.")).required(),  
                    profile_pic:Joi.any().error(new Error("Please select a profile picture.")).required(),  
                    name:Joi.string().error(new Error("Please enter the FullName.")).required(),       
                    email: Joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net', 'in', 'org', 'co'] } }).error(new Error("Please enter the Email.")).optional(),
                    category: Joi.string().error(new Error("Please enter the category.")).required(),       
                    front_view:Joi.any().error(new Error("Please select a front view.")).required(),  
                    back_view:Joi.any().error(new Error("Please select a back view.")).required(),  
                }),    
                failAction: (request, h, err) => {
                    throw err;
                    return false;
                },
            },
            payload: updateRouteOptions,            
    },
    path: URL.REGISTER_OD,
} );

const registerOwnerHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.registerOwner(request.payload,request.headers.authorization) 
    }    
}
const registerOwner  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: registerOwnerHandler( dataservice ),
        validate: {
                payload: Joi.object({
                    //id:Joi.number().error(new Error("Please enter id.")).required(),  
                    name:Joi.string().error(new Error("Please enter the FullName.")).required(),       
                    company:Joi.string().error(new Error("Please enter the Company.")).optional(),
                    present_address:Joi.string().error(new Error("Please enter the present_address.")).required(),
                    permanent_address:Joi.string().error(new Error("Please enter the permanent_address.")).required(),       
                    website:Joi.string().error(new Error("Please enter the website.")).optional(),
                    gst_number:Joi.string().error(new Error("Please enter the gst_number.")).optional(),
                    email: Joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net', 'in', 'org', 'co'] } }).error(new Error("Please enter the Email.")).optional(),
                    profile_pic:Joi.any().error(new Error("Please select a profile picture.")).required(),  
                    front_view:Joi.any().error(new Error("Please select a front view.")).required(),  
                    back_view:Joi.any().error(new Error("Please select a back view.")).required(), 
                    electricity_bill:Joi.any().error(new Error("Please select the electricity bill front view.")).required(),  
                }),    
                failAction: (request, h, err) => {
                    throw err;
                    return false;
                },
            },
            payload: updateRouteOptions,            
    },
    path: URL.REGISTER_OWNER,
} );


const vehilesUploadHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.vehilesUpload(request.payload) 
    }    
}
const vehilesUpload  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: vehilesUploadHandler( dataservice ),
        validate: {
                payload: Joi.object({
                    images:Joi.array().error(new Error("Please select images.")).required(),  
                    category : Joi.string().error(new Error("Please enter the category.")).required(),       
                }),    
                failAction: (request, h, err) => {
                    throw err;
                    return false;
                },
            },
            payload: updateRouteOptions,            
    },
    path: URL.VECHILES_UPLOAD,
} );


const vehileDetailsHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.vehileDetails(request.headers.authorization)  
    }    
}
const vehileDetails  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'GET',
    options: {
        handler: vehileDetailsHandler( dataservice ),        
    },
    path: URL.VECHILE_DETAILS,
} );


const timeSlotWorkTypeHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.timeSlotWorkType(request.payload,request.headers.authorization) 
    }    
}
const timeSlotWorkType  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: timeSlotWorkTypeHandler( dataservice ),
        validate: {
                payload: Joi.object({
                    //user_id:Joi.number().error(new Error("Please enter userid.")).required(),  
                    time_slot : Joi.string().error(new Error("Please enter the timeslot.")).required(),       
                    work_type : Joi.string().error(new Error("Please enter the worktype.")).required(),       
                }),    
                failAction: (request, h, err) => {
                    throw err;
                    return false;
                },
            },          
    },
    path: URL.TIMESLOT_WORKTYPE,
} );


const getProfileHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.getProfile(request.headers.authorization) 
    }    
}
const getProfile  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'GET',
    options: {
        handler: getProfileHandler( dataservice ),          
    },
    path: URL.GET_PROFILE,
} );

const operatorDriverVehilesHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.operatorDriverVehiles(request.payload,request.headers.authorization) 
    }    
}
const operatorDriverVehiles  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: operatorDriverVehilesHandler( dataservice ),          
    },
    path: URL.operatorDriverVehiles,
} );

const ownerVehilesHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.ownerVehiles(request.payload,request.headers.authorization) 
    }    
}
const ownerVehiles  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: ownerVehilesHandler( dataservice ),          
    },
    path: URL.ownerVehiles,
} );

const kycStatusChangeHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.kycStatusChange(request.payload,request.headers.authorization) 
    }    
}
const kycStatusChange  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: kycStatusChangeHandler( dataservice ),          
    },
    path: URL.kycStatusChange,
});

const kycStatusDetailsHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.kycStatusDetails(request.payload,request.headers.authorization) 
    }    
}
const kycStatusDetails  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: kycStatusDetailsHandler( dataservice ),          
    },
    path: URL.kycStatusDetails,
} );

const userPaymentDataHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.userPaymentData(request.payload,request.headers.authorization) 
    }    
}
const userPaymentData  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: userPaymentDataHandler( dataservice ),          
    },
    path: URL.userPaymentData,
} );

const userPaymentDataSaveHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
       // console.log( 'auth.route.js::registerHandler  request', request.payload );
        return dataservice.userPaymentDataSave(request.payload,request.headers.authorization) 
    }    
}
const userPaymentDataSave  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: userPaymentDataSaveHandler( dataservice ),          
    },
    path: URL.userPaymentDataSave,
} );

export default ( dataservice:  T.AuthAPIType ) => {
    return [
        loginmobileRoute( dataservice ), 
        verifyOTPRoute(dataservice),
        registerOperatorDriver(dataservice),
        registerOwner(dataservice),
        Welcome(dataservice),
        vehilesUpload(dataservice),
        vehileDetails(dataservice),
        timeSlotWorkType(dataservice),
        getProfile(dataservice),
        operatorDriverVehiles(dataservice),
        ownerVehiles(dataservice),
        kycStatusChange(dataservice),
        kycStatusDetails(dataservice),
        userPaymentData(dataservice),
        userPaymentDataSave(dataservice)
    ];
};