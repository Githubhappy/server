import { Server, } from '@hapi/hapi';
import { compose } from 'ramda';


const NPM_PACKAGE_BLANKIE = 'blankie';
const NPM_PACKAGE_INERT = 'inert';
const NPM_PACKAGE_PINO = 'hapi-pino';
const NPM_PACKAGE_SCOOTER = 'scooter';

const noop = (x: any) => 0;
const isTestEnv = process.env.NODE_ENV === 'test';
const isDevEnv = process.env.NODE_ENV === 'dev';

const registerInert = async (server: Server) =>
    server.register(require(NPM_PACKAGE_INERT));

const registerScooter = async (server: Server) =>
    server.register([require(NPM_PACKAGE_SCOOTER), {
        options: {}, // specify options here
        plugin: require(NPM_PACKAGE_BLANKIE),
    }]);

const registerPino = async (server: Server) => await server.register({
    options: {
        logPayload: isDevEnv,
        prettyPrint: true,
    },
    plugin: require(NPM_PACKAGE_PINO),
});


export const initPlugins = ( server: Server ) => {
    registerPino( server )
    registerInert( server );
    return server;    
};
