// auth.model.ts
/**
 * Implementation of Authentication Model
 * @packageDocumentation
 */
import jwtToken from '../utils/jwtValidation';
import jwtEncoder from '../utils/jwtValidation';
import { AuthDBConnection } from '../config/dbconnection'
import * as T from '../types/types';
import * as DB from '../utils/dbTables';
import { Console } from 'console';
import upload from '../utils/fileUpload';
import { string } from '@hapi/joi';
import { IoTJobsDataPlane } from 'aws-sdk';
//import * as C from './customer.model';
var springedge = require('springedge');
var moment = require('moment');


async function loginCheckDBOperation(input: any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);

    await DB.Login.forge()
        .query((qb) => {
            qb.column('id')
                .where('phone', '=', input)
        }
        )
        .fetch()
        .then((response: any) => {
            const res = response.toJSON();
            loginAPIresponse.id = res.id;
            loginAPIresponse.status = true;
            loginAPIresponse.message = 'Login Successful!';
        })
        .catch((error: any) => {
            loginAPIresponse.id = 0;
            loginAPIresponse.status = false;
            loginAPIresponse.message = error;
        });
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}
async function loginmobileDBOperation(input: any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };

    const otp = ("" + Math.random()).substring(2, 6);
    var params = {
        'sender': 'SEDEMO',
        'apikey': '6ms0gt855d4aa4q708n72m33k214568m1',
        'to': [
            '91' + input.phone  //Moblie Numbers 
        ],
        'message': `Hi, this is a ${otp} test message`,
        'format': 'json'
    };

    var loggedInUser = await loginCheckDBOperation(input.phone)

    var user_id = input.category.toUpperCase() == "OWNER" ? "OW":(input.category.toUpperCase() == "DRIVER" ? "DR" : (input.category.toUpperCase() == "OPERATOR" ? "OP" : "OD"))
    user_id = (user_id + input.phone.slice(5, 10))

    if (loggedInUser.status) {
        await DB.Login.forge()
            .query((qb) => {
                qb.column('id')
                    .where('id', '=', loggedInUser.id)
                    .where('phone', '=', input.phone).update({ otp: input.otp, otp_expire_at: new Date(Date.now()) })
            })
            .fetch()
            .then((response: any) => {
                console.log("sucess")
                const res = response.toJSON();
                loginAPIresponse.status = true
                loginAPIresponse.message = "OTP sent to Register mobile number successfully!"
            })
            .catch((err) => {
                console.log(err)
                loginAPIresponse.status = false
                loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number."
            })
    }
    else {
        await DB.Login.forge
            ({ 'phone': input.phone, 'otp': '1234', 'otp_expire_at': new Date(Date.now()), 'category': input.category,'user_id':user_id })
            .save()
            .then((response: any) => {
                console.log("sucess")
                const res = response.toJSON();
                loginAPIresponse.status = true
                loginAPIresponse.message = "OTP sent to mobile number successfully!"
            })
            .catch((err) => {
                console.log(err)
                loginAPIresponse.status = false
                loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number."
            })
    }

    //     let promise = new Promise(function (resolve, reject) {
    //         springedge.messages.send(params, 5000, async function (err, response) {
    //         if (err) {
    //             reject(err)

    //             // loginAPIresponse.status = false
    //             // loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number." 
    //         }
    //         else{

    //             await  Login.forge()
    //                 .query( ( qb ) => {
    //                         qb.column('id')
    //                         .where({'phone':input.phone})
    //                         .update({'otp':otp,'otp_expire_at': new Date(Date.now())})
    //                     }
    //                 )
    //                 .fetch()
    //                 .then( ( response : any ) =>  {
    //                     const res = response.toJSON();
    //                     console.log(res)
    //                     // loginAPIresponse.id = res.id;
    //                     // loginAPIresponse.status = true;
    //                     // loginAPIresponse.message = 'Login Successful!';
    //                 })
    //                 .catch( ( error : any ) => {
    //                     console.log('error')
    //                     // loginAPIresponse.id = 0;
    //                     // loginAPIresponse.status = false;
    //                     // loginAPIresponse.message = error;
    //                 });
    //             // loginAPIresponse.status = true
    //             // loginAPIresponse.message = "OTP sent to mobile successfully!"  
    //             resolve(response)
    //         }
    //         });
    //     }) 

    //    await promise.then(function (response) {
    //         console.log(response);
    //         loginAPIresponse.status = true
    //         loginAPIresponse.message = "OTP sent to mobile successfully!" 
    //         console.log("success") 
    //     }, function (err) {
    //         console.log('Err',err);
    //         loginAPIresponse.status = false
    //         loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number." 
    //     });
    return loginAPIresponse
}

async function verifyOTPRouteDBOperation(input: T.LoginAPIInputType): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var minsDiff,user_id,token,active
    await DB.Login.forge()
        .query((qb) => {
            qb.select('id','phone','category','user_id','active').where({ 'phone': input.phone, 'otp': input.otp })
        }
        )
        .fetch()
        .then(async(response: any) => {
            const res = response.toJSON();
            console.log("success")
            user_id = res.user_id
            active = res.active
            // var startDate = moment(res.otp_expire_at, 'YYYY-M-DD HH:mm:ss')
            // var endDate = moment(new Date(Date.now()), 'YYYY-M-DD HH:mm:ss')
            // minsDiff = endDate.diff(startDate, 'minutes')
            //loginAPIresponse.id = res.id
            loginAPIresponse.status = true;
            loginAPIresponse.message = 'Otp verified successfully!';
            await DB.Login.forge()
            .query((qb) => {
                qb.column('id')
                    .where('user_id', '=', user_id)
                    .update({ active: true})
            })
            .fetch()
            .then((response: any) => {
                console.log("sucess")
                const res = response.toJSON();
            })
            .catch((err) => {
                console.log(err)
            })
            await jwtToken.jwtEncoder(user_id)
            .then((res) => {
                console.log("-----res")
                token = res.data
                let data = {'active':active,'token': token.token, 'refreshToken': token.refresh };
                loginAPIresponse.data = data;
            })
            .catch((error) => {
                console.log("verifyOTPRouteDBOperation---",error)
            })
            // await jwtToken.jwtDecoder(token.token)
            // .then((res) => {
            //     console.log("-----res",res)
            //     //token = res.data
            //     //let data = {'token': token.token, 'refreshToken': token.refresh };
            //     //loginAPIresponse.data = data;
            // })
            // .catch((error) => {
            //     console.log("verifyOTPRouteDBOperation---",error)
            // })

        })
        .catch((error: any) => {
            console.log("fail")
            loginAPIresponse.status = false
            loginAPIresponse.message = "Unable to verify OTP. Please use a valid OTP."
            loginAPIresponse.data = {}
        });
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}

async function fileUpload(input: any, user_id:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    var data
    if (input.profile_pic && input.profile_pic.hapi.filename != '' && input.front_view && input.front_view.hapi.filename != '' && input.back_view && input.back_view.hapi.filename != '' || input.images) {
        await upload(input, user_id).then((resp) => {
            //console.log(resp)
            return resp;
        }).then(async (resp) => {
            //console.log("$$",resp)
            input.file = resp
            console.log(input.file)
            data = {
                status: true,
                message: 'Customer file uploaded',
                data: input
            }
        }).catch((err: any) => {
            console.log("customerFilesUploadHandler::-Err-", err)
            data = {
                status: false,
                message: 'Customer file not uploaded',
                data: {}
            }
        });
    }
    else {
        data = {
            status: false,
            message: 'Customer file not uploaded or file not selected'
        }
    }
    return data
}

async function registerOperatorDriver(input: any,auth:any): Promise<T.DBResponseType> {

    var loginAPIresponse: T.DBResponseType = {
        status: true
    };
    var phone, user_id: any;
    // await DB.Login.forge()
    //     .query((qb) => {
    //         qb.column('id', 'phone')
    //             .where('id', '=', input.id)
    //     })
    //     .fetch()
    //     .then((response: any) => {
    //         const res = response.toJSON();
    //         phone = res.phone
    //         loginAPIresponse.status = true
    //     })
    //     .catch((error: any) => {
    //         loginAPIresponse.status = false;
    //     });

    // user_id = input.category.toUpperCase() == "DRIVER" ? "DR" :(input.category.toUpperCase() == "OWNER"?"OW":(input.category.toUpperCase() == "OPERATOR" ? "OP" : "OD"))
    // user_id = (user_id + phone.slice(5, 10))

    var db:any, jwtInfo, jwt_user_id, jwt_phone
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    jwt_phone = jwtInfo.data.phone
    input.category=jwtInfo.data.category
    if(jwtInfo.status){
        var file_upload_status = await fileUpload(input,jwt_user_id)

        if(file_upload_status.status){
            if (loginAPIresponse.status) {
                await DB.driver_operator
                    .forge({ 'user_id': jwt_user_id, 'full_name': input.name, 'phone': jwt_phone, 'email': input.email, 'category': input.category, 'profile_pic': input.file[0], 'front_view': input.file[1], 'back_view': input.file[2] })
                    .save()
                    .then((res) => {
                        console.log("data saved")
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Registered successfully.';
                    })
                    .catch((err) => {
                        console.log("saved failed", err)
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Registered failed.';
                    })
            }
            else{
                loginAPIresponse.status = false
                loginAPIresponse.message = "Registration failed."
            }
        }
        else{
            loginAPIresponse = file_upload_status
        }
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse
}

async function registerOwner(input: any, auth:any): Promise<T.DBResponseType> {

    var loginAPIresponse: T.DBResponseType = {
        status: true
    };
    var phone, user_id: any;
    
    // await DB.Login.forge()
    //     .query((qb) => {
    //         qb.column('id', 'phone')
    //             .where('id', '=', input.id)
    //     })
    //     .fetch()
    //     .then((response: any) => {
    //         const res = response.toJSON();
    //         phone = res.phone
    //         loginAPIresponse.status = true
    //     })
    //     .catch((error: any) => {
    //         loginAPIresponse.status = false;
    //     });

    // user_id = ("OW" + phone.slice(5, 10))

    var db:any, jwtInfo, jwt_user_id, jwt_phone
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    jwt_phone = jwtInfo.data.phone
    input.category=jwtInfo.data.category
    if(jwtInfo.status){
        var file_upload_status = await fileUpload(input,jwt_user_id)

        if(file_upload_status.status){
            if (loginAPIresponse.status) {
                await DB.owner
                    .forge({ 'user_id': jwt_user_id, 'full_name': input.name, 'phone': jwt_phone, 'company':input.company,'website':input.website,'gst_number':input.gst_number ,'email': input.email, 'profile_pic': input.file[0], 'aadhar_front_view': input.file[1], 'aadhar_back_view': input.file[2],'electricity_bill':input.file[3],'permanent_address':input.permanent_address,'present_address':input.present_address })
                    .save()
                    .then((res) => {
                        console.log("data saved")
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Registered successfully.';
                    })
                    .catch((err) => {
                        console.log("saved failed", err)
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Registered failed.';
                    })
            }
            else{
                loginAPIresponse.status = false
                loginAPIresponse.message = "Registration failed."
            }
        }
        else{
            loginAPIresponse = file_upload_status
        }
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse
}

async function vehilesUpload(input: any): Promise<T.DBResponseType> {

    var loginAPIresponse: T.DBResponseType = {
        status: true
    };
    var phone, user_id: any;

    var file_upload_status = await fileUpload(input,"")
    console.log(input.file)
    if(file_upload_status.status){
        var wait_data=(input.file.map(async (element) => {
            await DB.vehicleList
            .forge({'category':input.category, 'vechile_urls':element })
            .save()
            .then((res) => {
                console.log("data saved")
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved successfully.';
            })
            .catch((err) => {
                console.log("saved failed", err)
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved failed.';
            })
        }))
        const users = await Promise.all(wait_data);
    }
    else{
        loginAPIresponse = file_upload_status
    }
    return loginAPIresponse
}

async function vehileDetails(auth:any): Promise<T.DBResponseType> {

    var loginAPIresponse: T.DBResponseType = {
        status: true
    };
    var data={}
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.vehicleList
            .forge()
            .query(qb=>{
                qb.select('id','vechile_urls').where({"category":"driver"})
            })
            .fetchAll()
            .then((res) => {
                console.log("data saved")
                
                console.log(data)
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved successfully.';
                data["driver"] = res.toJSON()
            })
            .catch((err) => {
                console.log("saved failed", err)
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved failed.';
                loginAPIresponse.data={}
            })
            await DB.vehicleList
            .forge()
            .query(qb=>{
                qb.select('id','vechile_urls').where({"category":"operator"})
            })
            .fetchAll()
            .then((res) => {
                console.log("data saved")
                
                console.log(data)
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved successfully.';
                data["operator"] = res.toJSON()
            })
            .catch((err) => {
                console.log("saved failed", err)
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved failed.';
                loginAPIresponse.data={}
            })
            loginAPIresponse.data = data
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }

    return loginAPIresponse
}


async function timeSlotWorkType(input: any, auth:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.timeslotWorktype.forge({'user_id':jwt_user_id,'time_slot':input.time_slot,'work_type':input.work_type})
            .save()
            .then((response: any) => {
                const res = response.toJSON();
                loginAPIresponse.id = res.id;
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data saved Successful!';
            })
            .catch((error: any) => {
                loginAPIresponse.id = 0;
                loginAPIresponse.status = false;
                loginAPIresponse.message = "Data saved failed.";
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}

async function getProfile(auth: any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        (jwt_user_id).split("")[0]==="O"?db = DB.owner:db=DB.driver_operator
        await db.forge()
            .query(qb=>{
                qb.select('*').where({"user_id":jwt_user_id})
            })
            .fetch()
            .then((response: any) => {
                const res = response.toJSON();
                loginAPIresponse.data = res
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'data fetched Successful!';
            })
            .catch((error: any) => {
                loginAPIresponse.status = false;
                loginAPIresponse.message = "User data not available.";
                loginAPIresponse.data={}
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}


async function operatorDriverVehiles(input:any,auth: any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    let tData=[]
    let vData = input.vechileDetails//[{'vehicle_id':2,'user_id':jwt_user_id},{'vehicle_id':3,'user_id':jwt_user_id}]
    console.log("----",[...vData])
    if(jwtInfo.status){
        var wait_data = (
            vData.map(async (element) => {
            element['user_id'] = jwt_user_id
            await DB.driver_operator_vehicles.forge(element)
                .save()
                .then((response: any) => {
                    const res = response.toJSON();
                    loginAPIresponse.data = res
                    tData.push(res)
                    loginAPIresponse.status = true;
                    loginAPIresponse.message = 'data saved Successful!';
                })
                .catch((error: any) => {
                    console.log(error)
                    loginAPIresponse.status = false;
                    loginAPIresponse.message = "Data saved failed.";
                    loginAPIresponse.data={}
                })
            }))
        let users = await Promise.all(wait_data);
        loginAPIresponse.data = tData
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}

async function ownerVehiles(input:any,auth: any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    let tData=[]
    let vData = input.vechileDetails//[{'vehicle_id':2,'user_id':jwt_user_id},{'vehicle_id':3,'user_id':jwt_user_id}]
    console.log("----",[...vData])
    if(jwtInfo.status){
        var wait_data = (
            vData.map(async (element) => {
            element['user_id'] = jwt_user_id
            await DB.owner_vehicles.forge(element)
                .save()
                .then((response: any) => {
                    const res = response.toJSON();
                    loginAPIresponse.data = res
                    tData.push(res)
                    loginAPIresponse.status = true;
                    loginAPIresponse.message = 'data saved Successful!';
                })
                .catch((error: any) => {
                    console.log(error)
                    loginAPIresponse.status = false;
                    loginAPIresponse.message = "Data saved failed.";
                    loginAPIresponse.data={}
                })
            }))
        let users = await Promise.all(wait_data);
        loginAPIresponse.data = tData
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    // console.log( '[auth.model.ts::loginAPI] called');
    return loginAPIresponse;
}


async function kycStatusChange(input: any, auth:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.kyc_status.forge()
            .query(qb=>{
                qb.select('*').where({"user_id":jwt_user_id})
            })
            .fetch()
            .then(async(response: any) => {
                const res = response.toJSON();
                //loginAPIresponse.data = res
                await DB.kyc_status.forge()
                    .query(qb=>{
                        qb.update({status:input.status}).where({"user_id":jwt_user_id})
                    })
                    .fetch()
                    .then((response: any) => {
                        const res = response.toJSON();
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'kyc status change Successful!';
                    })
                    .catch((error: any) => {
                        console.log(error)
                        loginAPIresponse.status = false;
                        loginAPIresponse.message = "kyc status fail.";
                        loginAPIresponse.data={}
                    })
            })
            .catch(async(error: any) => {
                await DB.kyc_status.forge({"user_id":jwt_user_id,'status':input.status,'document_type':input.document_type})
                    .save()
                    .then((response: any) => {
                        const res = response.toJSON();
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'kyc status saved Successful!';
                    })
                    .catch((error: any) => {
                        console.log(error)
                        loginAPIresponse.status = false;
                        loginAPIresponse.message = "kyc status fail.";
                        loginAPIresponse.data={}
                    })
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse;
}


async function kycStatusDetails(input: any, auth:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.kyc_status.forge()
            .query(qb=>{
                qb.select('user_id','status').where({"user_id":jwt_user_id})
            })
            .fetch()
            .then(async(response: any) => {
                const res = response.toJSON();
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'kyc status data fetch Successful!';
                loginAPIresponse.data = res
            })
            .catch(async(error: any) => {
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'kyc data fetch failed!';
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse;
}

async function userPaymentData(input: any, auth:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.user_payment_data.forge()
            .query(qb=>{
                qb.select('user_id','account_holder_name','account_number','ifsc_code','bank_name').where({"user_id":jwt_user_id})
            })
            .fetch()
            .then(async(response: any) => {
                const res = response.toJSON();
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'Bank data fetch Successful!';
                loginAPIresponse.data = res
            })
            .catch(async(error: any) => {
                loginAPIresponse.status = true;
                loginAPIresponse.message = 'Bank data fetch failed!';
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse;
}
async function userPaymentDataSave(input: any, auth:any): Promise<T.DBResponseType> {

    const loginAPIresponse: T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var db:any, jwtInfo, jwt_user_id
    jwtInfo = await jwtToken.jwtDecoder(auth);
    console.log("jwtinfo----",jwtInfo.data.user_id)
    jwt_user_id = jwtInfo.data.user_id
    if(jwtInfo.status){
        await DB.user_payment_data.forge()
            .query(qb=>{
                qb.select('user_id','account_holder_name','account_number','ifsc_code','bank_name').where({"user_id":jwt_user_id})
            })
            .fetch()
            .then(async(response: any) => {
                await DB.user_payment_data.forge()
                    .query(qb=>{
                        qb.update({'account_holder_name':input.account_holder_name,'account_number':input.account_number,'ifsc_code':input.ifsc_code,'bank_name':input.bank_name}).where({"user_id":jwt_user_id})
                    })
                    .fetch()
                    .then(async(response: any) => {
                        const res = response.toJSON();
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Bank data updated Successful!';
                        loginAPIresponse.data = res
                    })
                    .catch(async(error: any) => {
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Bank data fetch failed!';
                    });
            })
            .catch(async(error: any) => {
                await DB.user_payment_data.forge({"user_id":jwt_user_id,'account_holder_name':input.account_holder_name,'account_number':input.account_number,'ifsc_code':input.ifsc_code,'bank_name':input.bank_name})
                    .save()
                    .then(async(response: any) => {
                        const res = response.toJSON();
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Bank data saved Successful!';
                        loginAPIresponse.data = {}
                    })
                    .catch(async(error: any) => {
                        loginAPIresponse.status = true;
                        loginAPIresponse.message = 'Bank data saved failed!';
                    });
            });
    }
    else{
        loginAPIresponse.status = false;
        loginAPIresponse.message = "Jwt token issue.";
        loginAPIresponse.data={}
    }
    return loginAPIresponse;
}

const AuthModel: T.AuthAPIType = {
    login: loginCheckDBOperation,
    loginmobile: loginmobileDBOperation,
    verifyOTPRoute: verifyOTPRouteDBOperation,
    registerOperatorDriver: registerOperatorDriver,
    registerOwner:registerOwner,
    vehilesUpload:vehilesUpload,
    vehileDetails:vehileDetails,
    timeSlotWorkType:timeSlotWorkType,
    getProfile:getProfile,
    operatorDriverVehiles:operatorDriverVehiles,
    ownerVehiles:ownerVehiles,
    kycStatusChange:kycStatusChange,
    kycStatusDetails:kycStatusDetails,
    userPaymentData:userPaymentData,
    userPaymentDataSave:userPaymentDataSave
};

export default AuthModel;