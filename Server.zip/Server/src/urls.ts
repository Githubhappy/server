/* List of all URLs
 */

'use strict'

const AuthURLs = {
    LOGIN : '/api/login',
    LOGIN_MOBILE : '/api/loginMobile',
    LOGOUT : '/api/logout',
    VERIFY_OTP :'/api/verifyOtp',
    SAVE_IMG:'/api/saveImg',
    SAVE_SHOW:'/api/showImg',
    WELCOME: '/api/welcome',
    REGISTER_OD : '/api/registerOperatorDriver',
    REGISTER_OWNER : '/api/registerOwner',
    VECHILES_UPLOAD :'/api/vehilesUpload',
    VECHILE_DETAILS :'/api/vehileDetails',
    TIMESLOT_WORKTYPE :'/api/timeSlotWorktype',
    GET_PROFILE :'/api/getProfile',
    operatorDriverVehiles:'/api/operatorDriverVehiles',
    ownerVehiles:'/api/ownerVehiles',
    kycStatusChange:'/api/kycStatusChange',
    kycStatusDetails:'/api/kycStatusDetails',
    userPaymentData:'/api/userPaymentData',
    userPaymentDataSave:'/api/userPaymentDataSave'
}

export default {
    ...AuthURLs,
};
